@echo off
setlocal
rem nalssam's bunpil-pack : Windows double-click installer (ASCII only on purpose)
set "BUNPIL_ASK=1"
set "BUNPIL_WITH_TOOLS=1"
if not exist "%~dp0install.ps1" goto notextracted
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
goto done
:notextracted
powershell -NoProfile -Command "Write-Host ([regex]::Unescape('[!] \uc555\ucd95\uc744 \uba3c\uc800 \ud480\uc5b4 \uc8fc\uc138\uc694.')) -ForegroundColor Yellow; Write-Host ([regex]::Unescape('    zip \ud30c\uc77c\uc744 \uc624\ub978\ucabd \ud074\ub9ad -> [\ubaa8\ub450 \uc555\ucd95 \ud480\uae30] -> \ud480\ub9b0 \ud3f4\ub354\uc5d0\uc11c Install-Windows.bat \uc744 \ub2e4\uc2dc \uc2e4\ud589\ud569\ub2c8\ub2e4.')) -ForegroundColor Yellow; Write-Host ([regex]::Unescape('    \ub610\ub294 PowerShell\uc5d0 \ubd99\uc5ec\ub123\uae30:  irm https://nalssam-bunpil.vercel.app/install.ps1 | iex')) -ForegroundColor Gray"
:done
echo.
pause
