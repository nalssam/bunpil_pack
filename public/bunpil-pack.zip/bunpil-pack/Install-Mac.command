#!/bin/sh
# nalssam's 분필팩 — 맥에서 더블클릭으로 설치
cd "$(dirname "$0")" || exit 1
BUNPIL_ASK=1 BUNPIL_WITH_TOOLS=1 sh ./install.sh
echo ""
printf '%s' "창을 닫으려면 Enter 키를 누르세요... "
read -r _ || true
